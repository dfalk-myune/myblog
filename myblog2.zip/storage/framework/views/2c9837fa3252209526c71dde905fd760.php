<?php $__env->startSection('content'); ?>
    

    <h1>Profile of '<?php echo e($user->name); ?>' (content for admin)</h1>
    <a href="<?php echo e(route('admin.users.index')); ?>"  style="margin-right: 10px;"> Back </a>
    
    
    <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" style="display: inline;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger" style="margin-right: 10px;">Delete User</button>
    </form>

    <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-primary">Edit</a>
    

    <ul>
        <li>Name: <?php echo e($user->name); ?></li>
        <li>Email: <?php echo e($user->email); ?></li>
        <li>Role: '<?php echo e($user->role); ?>'</li>
        <li>ID: '<?php echo e($user->id); ?>'</li>
        
        <li>number of blogs: '<?php echo e($user->posts->count()); ?>'</li>
        
        
    </ul>
    
    
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/djf/laravelProjects/testing2/resources/views/admin/users/show.blade.php ENDPATH**/ ?>