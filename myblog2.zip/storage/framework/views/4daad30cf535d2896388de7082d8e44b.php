<?php $__env->startSection('content'); ?>
    <h1>Users (content for admin)</h1>
    

     <a href="<?php echo e(route('welcome')); ?>"  style="margin-right: 10px;"> Back </a>
     <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary" >Create User</a>

        
    <ul>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(route('admin.users.show', $user->id)); ?>" ><?php echo e($user->name); ?></a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/djf/laravelProjects/testing2/resources/views/admin/users/index.blade.php ENDPATH**/ ?>