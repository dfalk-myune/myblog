<?php $__env->startSection('content'); ?>
    <h1>Edit Blog Post of <?php if($post->user_id && $post->user): ?> 
        '<?php echo e($post->user->name); ?>'
    <?php else: ?>
        'Unknown User'
    <?php endif; ?></a>(Content for Admin)</h1>
    <a href="<?php echo e(url()-> previous()); ?>"  style="margin-right: 10px;"> Back </a>
    
    <form action="<?php echo e(route('admin.posts.update', $post->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="title">Title</label>
            <input type="text" name="title" class="form-control" value="<?php echo e($post->title); ?>" required></input>
        </div>
        <div class="form-group">
            <label for="content">Content</label>
            <textarea name="content" class="form-control" required><?php echo e($post->content); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/djf/laravelProjects/testing2/resources/views/admin/posts/edit.blade.php ENDPATH**/ ?>