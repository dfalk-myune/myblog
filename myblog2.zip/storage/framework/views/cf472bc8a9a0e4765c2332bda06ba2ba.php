<?php $__env->startSection('content'); ?>
    <h1>Post from: '<?php if($post->user_id && $post->user): ?> 
        <?php echo e($post->user->name); ?>

    <?php else: ?>
        Unknown User
    <?php endif; ?></a>' (Content for Admin)</h1>
    
    <a href="<?php echo e(route('admin.posts.index')); ?>"  style="margin-right: 10px;"> Back </a>
    
    <form action="<?php echo e(route('admin.posts.destroy', $post->id)); ?>" method="POST" style="display: inline;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger" style="margin-right: 10px;">Delete</button>
    </form>

    <a href="<?php echo e(route('admin.posts.edit', $post)); ?>" class="btn btn-primary">Edit</a>
    <ul>
        <li>ID: <?php echo e($post->id); ?></li>
        <li>Title: <?php echo e($post->title); ?></li>
        <li>Content:<?php echo e($post->content); ?></li>
        <li>Blogger:  
        <?php if($post->user_id && $post->user): ?> 
                    <?php echo e($post->user->name); ?>

                <?php else: ?>
                    Unknown User
                <?php endif; ?></a>
        </li>

    </ul>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/djf/laravelProjects/testing2/resources/views/admin/posts/show.blade.php ENDPATH**/ ?>