 

 <?php $__env->startSection('content'); ?>
 <!DOCTYPE html>
<html>
    <head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    

    <?php if(!Auth::check() ): ?>
    <meta http-equiv="refresh" content="0;url=<?php echo e(route('login')); ?>">

    <?php endif; ?>
    

    <?php if( Auth::check() && Auth::user()->role !== 'admin'): ?>
            <meta http-equiv="refresh" content="0;url=<?php echo e(route('posts.index')); ?>">
    <?php endif; ?>


    

    <title>Welcome</title>

    </head>

    <body>
        
    <?php if(Auth::check() && Auth::user()->role === 'admin'): ?>
    <h1>Admin Dashboard (content for admin) </h1>
    <ul>
        <li><a href="<?php echo e(route('admin.posts.index')); ?>">Manage Blog Posts</a></li>
        <li><a href="<?php echo e(route('admin.users.index')); ?>">Manage Users</a></li>
    </ul>
    <?php else: ?>
        <p>Redirecting...</p>
    <?php endif; ?>

    </body>

</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/djf/laravelProjects/testing2/resources/views/welcome.blade.php ENDPATH**/ ?>