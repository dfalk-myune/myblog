<?php $__env->startSection('content'); ?>
    <h1>Edit User : <?php echo e($user->name); ?></h1>
    <a href="<?php echo e(url()-> previous()); ?>"  style="margin-right: 10px;"> Back </a>
    
    
    <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" class="form-control" value="<?php echo e($user->email); ?>" required>
        </div>
        <div class="form-group">
            <label for="role">Role</label>
            <div>
                <label><input type="radio" name="role" value="admin" <?php echo e($user->role == 'admin' ? 'checked' : ''); ?>> Admin</label>
                <label><input type="radio" name="role" value="author" <?php echo e($user->role == 'author' ? 'checked' : ''); ?>> Author</label>
                <label><input type="radio" name="role" value="user" <?php echo e($user->role == 'user' ? 'checked' : ''); ?>> User</label>
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/djf/laravelProjects/testing2/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>