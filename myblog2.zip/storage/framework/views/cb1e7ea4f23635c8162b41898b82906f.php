<?php $__env->startSection('content'); ?>
    <h1>Create User </h1>
    <a href="<?php echo e(url()-> previous()); ?>"  style="margin-right: 10px;"> Back </a>
    
    
    <form action="<?php echo e(route('admin.users.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" name="name" class="form-control"   required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" class="form-control"   required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="text" name="password" class="form-control"   required>
        </div>
        <div class="form-group">
            <label for="role">Role</label>
            <div>
                <label><input type="radio" name="role" value="admin"  > Admin</label>
                <label><input type="radio" name="role" value="author"  > Author</label>
                <label><input type="radio" name="role" value="user" checked> User</label>
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Create</button>
    </form>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/djf/laravelProjects/testing2/resources/views/admin/users/create.blade.php ENDPATH**/ ?>