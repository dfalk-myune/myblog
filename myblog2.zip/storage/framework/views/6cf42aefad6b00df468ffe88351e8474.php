<?php $__env->startSection('content'); ?>
    <h1>Blog Posts Create</h1>
    
    <form action="<?php echo e(route('admin.posts.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="title">Title</label>
            <input type="text" name="title" class="form-control" required></input>
        </div>
        <div class="form-group">
            <label for="content">Content</label>
            <textarea name="content" class="form-control" required ></textarea>
        </div>
        <button type="submit" class="btn btn-primary">submit</button>
    </form>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/djf/laravelProjects/testing2/resources/views/admin/posts/create.blade.php ENDPATH**/ ?>