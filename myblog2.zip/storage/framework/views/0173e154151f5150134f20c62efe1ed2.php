<?php $__env->startSection('content'); ?>
    <h1>Blog Posts  (<?php echo e(Str::ucfirst(Auth::user()->role)); ?>)
        
        

</h1>


    
    <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary" >Create Post</a>
    
        
    <ul>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(route('posts.show', $post->id)); ?>" ><?php echo e($post->title); ?> 
                
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>
    

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/djf/laravelProjects/testing2/resources/views/Posts/index.blade.php ENDPATH**/ ?>