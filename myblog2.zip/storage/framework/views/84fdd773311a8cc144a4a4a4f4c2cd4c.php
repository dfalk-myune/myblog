<?php $__env->startSection('content'); ?>
    <h1>Blog Posts Details</h1>
    
    <a href="<?php echo e(url()-> previous()); ?>"  style="margin-right: 10px;">  Back </a>
    
    <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST" style="display: inline;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger" style="margin-right: 10px;">Delete</button>
    </form>

    <a href="<?php echo e(route('posts.edit', $post)); ?>" class="btn btn-primary">Edit</a>
    <ul>
        <li>ID: <?php echo e($post->id); ?></li>
        <li>Title: <?php echo e($post->title); ?></li>
        <li>Content:<?php echo e($post->content); ?></li>

    </ul>
    

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/djf/laravelProjects/testing2/resources/views/Posts/show.blade.php ENDPATH**/ ?>